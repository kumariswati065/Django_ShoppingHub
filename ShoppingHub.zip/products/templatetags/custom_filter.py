from django import template

register = template.Library()

@register.filter
def currency(number):
    return "₹"+str(number)


@register.filter
def multiply(number , number1):
    return number * number1

