from django.shortcuts import render, redirect
from products.models import Customer
from django.views import View
from django.contrib.auth.hashers import check_password
from products.models import Product
from products.models import Order
from products.middlewares.auth import auth_middleware
from django.utils.decorators import method_decorator

class OrderView(View):


    def get(self , request):
        customer = request.session.get('customer')
        orders = Order.get_orders_by_customer(customer)
        print(orders)
        return render(request , 'orders.html' , {'orders' : orders})